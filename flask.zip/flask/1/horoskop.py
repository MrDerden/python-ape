# HOROSKOP
# Przygotuj stronę we flasku z horoskopem.
# Stwórz listę ogólnych i zawsze dobrych porad życiowych,
# typu "Nigdy nie jest za późno" albo "Ważne są tylko te dni których jeszcze nie znamy"
# Niech program wylosuje jedną z porad i umieści ją w templatece.
# Przy odświeżeniu strony powinna pojawić się inna porada.