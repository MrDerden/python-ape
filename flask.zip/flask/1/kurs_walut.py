# KURS WALUT
# Napisz aplikację we flasku, która pokaże kurs dolara amerykańskigo, funta i euro na dziś.
# Możesz wykorzystać kod z zajęć nr 11 (pobiernaie danych z serweru NBP)